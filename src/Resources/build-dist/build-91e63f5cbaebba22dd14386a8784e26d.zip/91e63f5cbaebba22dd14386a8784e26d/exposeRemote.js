
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.datadefinitions = "/bundles/datadefinitions/studio/91e63f5cbaebba22dd14386a8784e26d/static/js/remoteEntry.js"

      
    